using System.ComponentModel.DataAnnotations;
using System;
namespace testservice.Models
{
    public class Membership
    {
        [Key]
        public string username { get; set; }
        public string password { get; set; }
        public int age { get; set; }

    }
}