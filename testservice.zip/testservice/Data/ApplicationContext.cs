using Microsoft.EntityFrameworkCore;
using testservice.Models;

namespace testservice.Data
{
    public class ApplicationContext: DbContext
    {
        public ApplicationContext(DbContextOptions option): 
        base(option)
        {
            
        }

        public DbSet<Membership> users { get; set; }
        
    }
}